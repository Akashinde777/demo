package com.assignment.demo.controllers;

import jakarta.inject.Inject;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AuthorControllerTest {
    @Inject
    AuthorController authorController;

    @Test
    @DisplayName("testAuthor")
    void testAddAuthor() {

    }
}
