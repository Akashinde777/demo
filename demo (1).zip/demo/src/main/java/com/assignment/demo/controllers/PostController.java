package com.assignment.demo.controllers;

public class PostController {
}
