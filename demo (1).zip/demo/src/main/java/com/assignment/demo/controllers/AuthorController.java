package com.assignment.demo.controllers;

import com.assignment.demo.dtos.AuthorDto;
import com.assignment.demo.services.AuthorService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/author")
@Slf4j
public class AuthorController {

    private final AuthorService authorService;

    AuthorController(AuthorService authorService){
        this.authorService = authorService;
    }
    @PostMapping
    public ResponseEntity<AuthorDto> addAuthor(@RequestBody AuthorDto author) {
        AuthorDto responseBody = new AuthorDto();
        try {
            log.info("Adding  author.");
            responseBody = authorService.addAuthor(author);
            log.info("Author added successfully. id: {}", responseBody.getId());
            return new ResponseEntity(responseBody, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while adding  author {}", e.getMessage());
        }
        return new ResponseEntity<>(responseBody, HttpStatus.INTERNAL_SERVER_ERROR);
    }


    //Api for get all the authors.
    @GetMapping
    public ResponseEntity<List<AuthorDto>> getAllAuthors() {
        List<AuthorDto> responseBody = new ArrayList<>();
        try {
            responseBody = authorService.getAllAuthors();
            return new ResponseEntity(responseBody, HttpStatus.OK);
        } catch (Exception e) {
            log.error("Error while creating author {}", e.getMessage());
        }
        return new ResponseEntity<>(responseBody, HttpStatus.INTERNAL_SERVER_ERROR);
    }



}
