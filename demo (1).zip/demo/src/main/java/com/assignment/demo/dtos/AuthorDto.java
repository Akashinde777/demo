package com.assignment.demo.dtos;

import lombok.Data;

@Data
public class AuthorDto {
    private Integer id;
    private String name;
}
