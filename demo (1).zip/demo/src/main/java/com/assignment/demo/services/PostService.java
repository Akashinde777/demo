package com.assignment.demo.services;

public interface PostService {
}
