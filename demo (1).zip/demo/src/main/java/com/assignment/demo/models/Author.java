package com.assignment.demo.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.Entity;
import jakarta.persistence.OneToMany;
import lombok.Getter;
import lombok.Setter;

import java.util.List;

@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class Author extends BaseModel{
    private String name;

//    @JsonManagedReference // This annotation helps manage the serialization
//    @JsonIgnore
//    @OneToMany(fetch = jakarta.persistence.FetchType.LAZY, mappedBy = "author")
//    private List<Post> posts;
}
