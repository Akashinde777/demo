package com.assignment.demo.services;

import com.assignment.demo.dtos.AuthorDto;
import com.assignment.demo.models.Author;
import com.assignment.demo.repositories.AuthorRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AuthorServiceImpl implements AuthorService{

    private final ObjectMapper objectMapper;

    private AuthorRepository authorRepository;

    AuthorServiceImpl(ObjectMapper objectMapper,AuthorRepository authorRepository){
        this.objectMapper = objectMapper;
        this.authorRepository = authorRepository;
    }
    @Override
    public AuthorDto addAuthor(AuthorDto author) {
        Author authorEntity = convertAuthorDtoToAuthotModel(author);
        authorEntity = authorRepository.save(authorEntity);
        AuthorDto authorDto = convertModelToDto(authorEntity);

        return authorDto;
    }

    @Override
    public List<AuthorDto> getAllAuthors() {
        List<AuthorDto> authorDtos = new ArrayList<>();
        List<Author> result = authorRepository.findAll();
        for(Author author : result){
            AuthorDto authorDto= convertModelToDto(author);
            authorDtos.add(authorDto);
        }
        return authorDtos;
    }

    private  Author convertAuthorDtoToAuthotModel(AuthorDto authorDto){
        Author author =objectMapper.convertValue(authorDto,Author.class);
        author.setId(authorDto.getId());
        return author;
    }
    private AuthorDto convertModelToDto(Author authorEntity){
        return objectMapper.convertValue(authorEntity,AuthorDto.class);
    }

}
