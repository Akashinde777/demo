package com.assignment.demo.dtos;

import lombok.Data;

@Data
public class PostDto {
    private String text;
    private Boolean isDeleted;
    private Integer authorId;
}
