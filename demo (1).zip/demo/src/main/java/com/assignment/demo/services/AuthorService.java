package com.assignment.demo.services;

import com.assignment.demo.dtos.AuthorDto;

import java.util.List;

public interface AuthorService {
    public AuthorDto addAuthor(AuthorDto author);

     public List<AuthorDto> getAllAuthors();
}
