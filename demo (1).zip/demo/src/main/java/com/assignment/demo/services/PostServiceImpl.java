package com.assignment.demo.services;

import org.springframework.stereotype.Service;

@Service
public class PostServiceImpl implements PostService{
}
