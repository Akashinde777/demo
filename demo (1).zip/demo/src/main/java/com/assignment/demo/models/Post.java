package com.assignment.demo.models;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonManagedReference;
import jakarta.persistence.Entity;
import jakarta.persistence.ManyToOne;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
@Entity
@JsonIgnoreProperties(ignoreUnknown = true)
public class Post extends BaseModel{
    private String text;

    private Boolean isDeleted;

    @JsonManagedReference // This annotation helps manage the serialization
    @JsonIgnore
    @ManyToOne(optional = false)
    private Author author;
}
